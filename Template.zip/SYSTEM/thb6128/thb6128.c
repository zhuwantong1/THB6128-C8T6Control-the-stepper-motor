#include "thb6128.h"
#include "usart.h" 
u8 STEP;
int COUNT_MO=0;
/* EN->     PA11        M1    PB13
   CW/CCW-> PA12				M2		PB14
	 CLK/cp->    PA8 				M3		PB15
	 VREF->   PA4  
	 FDT->    PA5
*/ 
void STEP_MOTOR_Init(void){ //接口初始化
	
	  GPIO_InitTypeDef  GPIO_InitStructure;
 	
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE);	 //使能PB,PE端口时钟
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_8;				 // 端口配置
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //推挽输出
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO口速度为50MHz
		GPIO_Init(GPIOA, &GPIO_InitStructure);					 //根据设定参数初始化
						 

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;				 //LED0-->PC13 端口配置
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //推挽输出
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO口速度为50MHz
		GPIO_Init(GPIOB, &GPIO_InitStructure);					 //根据设定参数初始化


		//使用PA0来检查MO端口的高低电平
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;		// 引脚
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;	// 模式：输入模式
		GPIO_Init(GPIOA, &GPIO_InitStructure);
}
void CHECK_MO(void)
{
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)
		COUNT_MO++;
  		
}




void STEP_MOTOR_FORWARD(void)
{
	if(USART_RX_BUF[0]=='+')
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_12); //,一定要注意初始化，将函数提前声明，将PA12拉低，正转	
	//	printf("forward\r\n");
	}
}
void STEP_MOTOR_BACKWARD(void)
{
	if(USART_RX_BUF[0]=='-')
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_12);  //将PA12拉高，反转			
	 // printf("back\r\n");
	}
}	





void STEP_MOTOR_OFF (void)  //直接失能clk
{
	if(USART_RX_BUF[0]=='O'&& USART_RX_BUF[1]=='F'&& USART_RX_BUF[2]=='F')
		 RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, DISABLE);	
}
void STEP_MOTOR_OPEN (void)  //直接使能clk
{
	if(USART_RX_BUF[0]=='O'&& USART_RX_BUF[1]=='P'&& USART_RX_BUF[2]=='E'&& USART_RX_BUF[3]=='N')
		 RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);	
}
void STEP_MOTOR_NUM_STOP (void)  //
{
	switch (USART_RX_BUF[0]){
		case 1:
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    delay_ms(1000);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, DISABLE);	
			break;
		case 2:
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    delay_ms(2000);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, DISABLE);
			break;
		case 3:
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    delay_ms(3000);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, DISABLE);
			break;
		case 4:
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    delay_ms(4000);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, DISABLE);
			break;
		default:
			break;
	}
	STEP_MOTOR_OFF();//进入断电状态，防电机过热
}
 
 
//void STEP_MOTOR_NUM (u8 RL,u16 num,u8 speed)  //电机按步数运行
//{
//	u16 i;
//	for(i=0;i<num;i++)
//    {	
//		if(RL==1){ //当RL=1右转，RL=0左转
//			STEP++;
//			if(STEP>7)STEP=0;
//		}else{
//			if(STEP==0)STEP=8;
//			STEP--;
//		}
//	}
//}
// 
//void STEP_MOTOR_LOOP (u8 RL,u8 LOOP,u8 speed)  //电机按圈数运行
//{
//	STEP_MOTOR_NUM(RL,LOOP*4076,speed); 
//}
