#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "thb6128.h"
#include "timer.h"

extern int COUNT_MO;
 int main(void)
 {	
	 
	  u16 t;  
	  u16 len;	
	  //clk应该接在有定时器的io接口上，PA8 PB5,复用且用线连接
		delay_init();	    	 //延时函数初始化	  
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 	 //设置NVIC中断分组2:2位抢占优先级，2位响应优先级
		uart_init(115200);	 	//串口初始化为 115200,用的串口1，PA9->RX ,PA10->TX
		STEP_MOTOR_Init();
	  LED_Init();			     //LED端口初始化
		TIM1_PWM_Init(99,7199);	 //分频得到10Khz 。PWM频率=72000000/9999/7199=1hz
		TIM3_Int_Init(99,7199);  //现在是100hz对应99
		

		while(1)
		{
				
		    TIM_SetCompare1(TIM1,50);	
//  		TIM_SetCompare2(TIM3,360);	
//			delay_ms(3000);
//			RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, DISABLE);	
//			delay_ms(3000);
//			RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);	
//			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	
		  if(USART_RX_STA&0x8000)
			{					   
				len=USART_RX_STA&0x3fff;//得到此次接收到的数据长度
				for(t=0;t<len;t++)
				{
					USART_SendData(USART1, USART_RX_BUF[t]);//向串口1发送数据
					while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//等待发送结束
				}
				USART_RX_STA=0;
			}	
			STEP_MOTOR_FORWARD();
			STEP_MOTOR_BACKWARD();
			STEP_MOTOR_OPEN (); //检测输入OPEN,OFF,+,-		
			STEP_MOTOR_OFF (); 			
			
			
			
//			if(USART_RX_BUF[0]=='o'&&  USART_RX_BUF[1]=='p'&&USART_RX_BUF[2] =='e'&&USART_RX_BUF[3]=='n'  )//判断串口接收到的信息,把灯点亮
//				{
////					printf("already open \r\n");
//					LED0=0;
//				}				
		//  CHECK_MO();
		//	printf("Already turned %d times \r\n",COUNT_MO);
		//	STEP_MOTOR_NUM_STOP();
				
					
		
		}
	}



